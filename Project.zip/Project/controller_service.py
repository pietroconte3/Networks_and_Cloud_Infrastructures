#!/usr/bin/python3
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3

IP_PROTO_ICMP = 1
IP_PROTO_TCP  = 6
IP_PROTO_UDP  = 17
VIDEO_PORT    = 9999

PRIO_LOCAL      = 60
PRIO_ARP        = 50
PRIO_VIDEO      = 40
PRIO_NON_VIDEO  = 30
PRIO_GUARD      = 20
PRIO_DROP       = 0

class SliceController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def add_flow(self, dp, prio, match, actions):
        p, ofp = dp.ofproto_parser, dp.ofproto
        inst = [p.OFPInstructionActions(ofp.OFPIT_APPLY_ACTIONS, actions)]
        dp.send_msg(p.OFPFlowMod(datapath=dp, priority=prio, match=match, instructions=inst))

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features(self, ev):
        dp  = ev.msg.datapath
        ofp = dp.ofproto
        p   = dp.ofproto_parser
        dpid = dp.id

        self.add_flow(dp, PRIO_DROP, p.OFPMatch(), [])
        self.add_flow(dp, PRIO_ARP, p.OFPMatch(eth_type=0x0806),
                      [p.OFPActionOutput(ofp.OFPP_FLOOD)])

        if dpid == 1:
            self.add_flow(dp, PRIO_LOCAL,
                          p.OFPMatch(eth_type=0x0800, in_port=1, ipv4_dst="10.0.0.2"),
                          [p.OFPActionOutput(2)])
            self.add_flow(dp, PRIO_LOCAL,
                          p.OFPMatch(eth_type=0x0800, in_port=2, ipv4_dst="10.0.0.1"),
                          [p.OFPActionOutput(1)])

            for inport in (1, 2):
                self.add_flow(dp, PRIO_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                              [p.OFPActionOutput(3)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_NON_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_ICMP),
                              [p.OFPActionOutput(4)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_NON_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_TCP),
                              [p.OFPActionOutput(4)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_GUARD,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_UDP),
                              [p.OFPActionOutput(4)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_GUARD,
                              p.OFPMatch(eth_type=0x0800, in_port=inport),
                              [p.OFPActionOutput(4)])
            for inport in (3, 4):
                self.add_flow(dp, PRIO_LOCAL,
                              p.OFPMatch(eth_type=0x0800, in_port=inport, ipv4_dst="10.0.0.1"),
                              [p.OFPActionOutput(1)])
                self.add_flow(dp, PRIO_LOCAL,
                              p.OFPMatch(eth_type=0x0800, in_port=inport, ipv4_dst="10.0.0.2"),
                              [p.OFPActionOutput(2)])

        elif dpid == 2:
            self.add_flow(dp, PRIO_VIDEO,
                          p.OFPMatch(eth_type=0x0800, in_port=1,
                                     ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                          [p.OFPActionOutput(2)])
            self.add_flow(dp, PRIO_VIDEO,
                          p.OFPMatch(eth_type=0x0800, in_port=2,
                                     ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                          [p.OFPActionOutput(1)])

        elif dpid == 3:
            self.add_flow(dp, PRIO_VIDEO,
                          p.OFPMatch(eth_type=0x0800, ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                          [])
            self.add_flow(dp, PRIO_NON_VIDEO,
                          p.OFPMatch(eth_type=0x0800, in_port=1),
                          [p.OFPActionOutput(2)])
            self.add_flow(dp, PRIO_NON_VIDEO,
                          p.OFPMatch(eth_type=0x0800, in_port=2),
                          [p.OFPActionOutput(1)])

        elif dpid == 4:
            self.add_flow(dp, PRIO_LOCAL,
                          p.OFPMatch(eth_type=0x0800, in_port=1, ipv4_dst="10.0.0.4"),
                          [p.OFPActionOutput(2)])
            self.add_flow(dp, PRIO_LOCAL,
                          p.OFPMatch(eth_type=0x0800, in_port=2, ipv4_dst="10.0.0.3"),
                          [p.OFPActionOutput(1)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                              [p.OFPActionOutput(3)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_NON_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_ICMP),
                              [p.OFPActionOutput(4)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_NON_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_TCP),
                              [p.OFPActionOutput(4)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_GUARD,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_UDP),
                              [p.OFPActionOutput(4)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_GUARD,
                              p.OFPMatch(eth_type=0x0800, in_port=inport),
                              [p.OFPActionOutput(4)])
            for inport in (3, 4):
                self.add_flow(dp, PRIO_LOCAL,
                              p.OFPMatch(eth_type=0x0800, in_port=inport, ipv4_dst="10.0.0.3"),
                              [p.OFPActionOutput(1)])
                self.add_flow(dp, PRIO_LOCAL,
                              p.OFPMatch(eth_type=0x0800, in_port=inport, ipv4_dst="10.0.0.4"),
                              [p.OFPActionOutput(2)])

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in(self, ev):
        return

