#!/usr/bin/python3
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib import hub
import time

IP_PROTO_ICMP = 1
IP_PROTO_TCP  = 6
IP_PROTO_UDP  = 17
VIDEO_PORT    = 9999

PRIO_LOCAL      = 60
PRIO_ARP        = 50
PRIO_VIDEO      = 40
PRIO_NON_VIDEO  = 30
PRIO_GUARD      = 20
PRIO_DROP       = 0

class SliceController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(SliceController, self).__init__(*args, **kwargs)
        self.video_active = False
        self.video_throughput = 0.0
        self.flow_stats = {}
        self.datapaths = {}
        hub.spawn(self._monitor)

    @set_ev_cls(ofp_event.EventOFPStateChange, [MAIN_DISPATCHER])
    def _state_change_handler(self, ev):
        dp = ev.datapath
        if ev.state == MAIN_DISPATCHER:
            self.datapaths[dp.id] = dp

    def _monitor(self):
        while True:
            for dp in self.datapaths.values():
                parser = dp.ofproto_parser
                req = parser.OFPFlowStatsRequest(dp)
                dp.send_msg(req)
            self._update_dynamic_rules()
            hub.sleep(5)

    def add_flow(self, dp, prio, match, actions):
        p, ofp = dp.ofproto_parser, dp.ofproto
        inst = [p.OFPInstructionActions(ofp.OFPIT_APPLY_ACTIONS, actions)]
        dp.send_msg(p.OFPFlowMod(datapath=dp, priority=prio, match=match, instructions=inst))

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features(self, ev):
        dp  = ev.msg.datapath
        ofp = dp.ofproto
        p   = dp.ofproto_parser
        dpid = dp.id

        self.add_flow(dp, PRIO_DROP, p.OFPMatch(), [])
        self.add_flow(dp, PRIO_ARP, p.OFPMatch(eth_type=0x0806),
                      [p.OFPActionOutput(ofp.OFPP_FLOOD)])

        if dpid == 1:
            self.add_flow(dp, PRIO_LOCAL, p.OFPMatch(eth_type=0x0800, in_port=1, ipv4_dst="10.0.0.2"),
                          [p.OFPActionOutput(2)])
            self.add_flow(dp, PRIO_LOCAL, p.OFPMatch(eth_type=0x0800, in_port=2, ipv4_dst="10.0.0.1"),
                          [p.OFPActionOutput(1)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                              [p.OFPActionOutput(3)])
            for inport in (1, 2):
                for proto in (IP_PROTO_ICMP, IP_PROTO_TCP, IP_PROTO_UDP):
                    self.add_flow(dp, PRIO_NON_VIDEO,
                                  p.OFPMatch(eth_type=0x0800, in_port=inport, ip_proto=proto),
                                  [p.OFPActionOutput(4)])
                self.add_flow(dp, PRIO_GUARD,
                              p.OFPMatch(eth_type=0x0800, in_port=inport),
                              [p.OFPActionOutput(4)])
            for inport in (3, 4):
                self.add_flow(dp, PRIO_LOCAL,
                              p.OFPMatch(eth_type=0x0800, in_port=inport, ipv4_dst="10.0.0.1"),
                              [p.OFPActionOutput(1)])
                self.add_flow(dp, PRIO_LOCAL,
                              p.OFPMatch(eth_type=0x0800, in_port=inport, ipv4_dst="10.0.0.2"),
                              [p.OFPActionOutput(2)])

        elif dpid == 2:
            for inport in (1, 2):
                self.add_flow(dp, PRIO_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                              [p.OFPActionOutput(3 - inport)])

        elif dpid == 3:
            self.add_flow(dp, PRIO_VIDEO,
                          p.OFPMatch(eth_type=0x0800, ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                          [])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_NON_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport),
                              [p.OFPActionOutput(3 - inport)])

        elif dpid == 4:
            self.add_flow(dp, PRIO_LOCAL, p.OFPMatch(eth_type=0x0800, in_port=1, ipv4_dst="10.0.0.4"),
                          [p.OFPActionOutput(2)])
            self.add_flow(dp, PRIO_LOCAL, p.OFPMatch(eth_type=0x0800, in_port=2, ipv4_dst="10.0.0.3"),
                          [p.OFPActionOutput(1)])
            for inport in (1, 2):
                self.add_flow(dp, PRIO_VIDEO,
                              p.OFPMatch(eth_type=0x0800, in_port=inport,
                                         ip_proto=IP_PROTO_UDP, udp_dst=VIDEO_PORT),
                              [p.OFPActionOutput(3)])
                for proto in (IP_PROTO_ICMP, IP_PROTO_TCP, IP_PROTO_UDP):
                    self.add_flow(dp, PRIO_NON_VIDEO,
                                  p.OFPMatch(eth_type=0x0800, in_port=inport, ip_proto=proto),
                                  [p.OFPActionOutput(4)])
                self.add_flow(dp, PRIO_GUARD,
                              p.OFPMatch(eth_type=0x0800, in_port=inport),
                              [p.OFPActionOutput(4)])
            for inport in (3, 4):
                self.add_flow(dp, PRIO_LOCAL,
                              p.OFPMatch(eth_type=0x0800, in_port=inport, ipv4_dst="10.0.0.3"),
                              [p.OFPActionOutput(1)])
                self.add_flow(dp, PRIO_LOCAL,
                              p.OFPMatch(eth_type=0x0800, in_port=inport, ipv4_dst="10.0.0.4"),
                              [p.OFPActionOutput(2)])

        if len(self.datapaths) >= 4:
            self.logger.info("Inizializzazione slicing dinamico.")
            self._update_dynamic_rules()

    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def _flow_stats_reply_handler(self, ev):
        body = ev.msg.body
        dpid = ev.msg.datapath.id
        current_time = time.time()
        video_values = []
        for stat in body:
            match = stat.match
            if "udp_dst" in match and match["udp_dst"] == VIDEO_PORT:
                flow_key = (dpid, str(match))
                if flow_key in self.flow_stats:
                    prev_time, prev_bytes = self.flow_stats[flow_key]
                    delta_bytes = stat.byte_count - prev_bytes
                    delta_time = current_time - prev_time
                    if delta_time > 0 and delta_bytes > 0:
                        throughput_mbps = (delta_bytes * 8) / (delta_time * 1_000_000)
                        video_values.append(throughput_mbps)
                self.flow_stats[flow_key] = (current_time, stat.byte_count)
        if video_values:
            avg_video = sum(video_values) / len(video_values)
            self.video_throughput = avg_video
            self.video_active = avg_video > 1.0
        else:
            self.video_throughput = 0.0
            self.video_active = False
        self.logger.info(">>> Video active: %s (Throughput medio: %.3f Mbps)",
                         self.video_active, self.video_throughput)
        self._update_dynamic_rules()

    def _update_dynamic_rules(self):
        for dp in self.datapaths.values():
            dpid = dp.id
            parser = dp.ofproto_parser
            ofp = dp.ofproto
            if dpid in (1, 4):
                if self.video_active:
                    self.logger.info("Video ATTIVO")
                    for proto in (IP_PROTO_ICMP, IP_PROTO_TCP, IP_PROTO_UDP):
                        for inport in (1, 2):
                            match = parser.OFPMatch(eth_type=0x0800, in_port=inport, ip_proto=proto)
                            mod = parser.OFPFlowMod(
                                datapath=dp,
                                command=ofp.OFPFC_DELETE,
                                out_port=ofp.OFPP_ANY,
                                out_group=ofp.OFPG_ANY,
                                priority=PRIO_NON_VIDEO + 10,
                                match=match
                            )
                            dp.send_msg(mod)
                            self.logger.info(f"[Dynamic] Rimossa regola dinamica {proto} su S{dpid} (porta {inport})")
                    for proto in (IP_PROTO_ICMP, IP_PROTO_TCP, IP_PROTO_UDP):
                        for inport in (1, 2):
                            match = parser.OFPMatch(eth_type=0x0800, in_port=inport, ip_proto=proto)
                            actions = [parser.OFPActionOutput(4)]
                            inst = [parser.OFPInstructionActions(ofp.OFPIT_APPLY_ACTIONS, actions)]
                            dp.send_msg(parser.OFPFlowMod(
                                datapath=dp,
                                priority=PRIO_NON_VIDEO,
                                match=match,
                                instructions=inst
                            ))
                    self.logger.info(f"[Dynamic] Regole S{dpid}: reindirizzate non-video su S3 ")
                    if 2 in self.datapaths:
                        dp2 = self.datapaths[2]
                        p2, ofp2 = dp2.ofproto_parser, dp2.ofproto
                        for inport in (1, 2):
                            dp2.send_msg(p2.OFPFlowMod(
                                datapath=dp2,
                                command=ofp2.OFPFC_DELETE,
                                out_port=ofp2.OFPP_ANY,
                                out_group=ofp2.OFPG_ANY,
                                match=p2.OFPMatch(eth_type=0x0800, in_port=inport, ip_proto=IP_PROTO_ICMP)
                            ))
                        self.logger.info("[Dynamic] ICMP rimosse da S2 durante video attivo")
                else:
                    self.logger.info("Video NON ATTIVO")
                    for proto, name in [(IP_PROTO_ICMP, "ICMP"), (IP_PROTO_TCP, "TCP"), (IP_PROTO_UDP, "UDP")]:
                        for inport in (1, 2):
                            match = parser.OFPMatch(eth_type=0x0800, in_port=inport, ip_proto=proto)
                            actions = [parser.OFPActionOutput(3)]
                            inst = [parser.OFPInstructionActions(ofp.OFPIT_APPLY_ACTIONS, actions)]
                            dp.send_msg(parser.OFPFlowMod(
                                datapath=dp,
                                priority=PRIO_NON_VIDEO + 10,
                                match=match,
                                instructions=inst
                            ))
                            self.logger.info(f"[Dynamic] Regola {name} → S2 aggiunta su S{dpid}")
                    if 2 in self.datapaths:
                        dp2 = self.datapaths[2]
                        p2 = dp2.ofproto_parser
                        self.add_flow(dp2, 40, p2.OFPMatch(eth_type=0x0800, ip_proto=1, in_port=1),
                                      [p2.OFPActionOutput(2)])

