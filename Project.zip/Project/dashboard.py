from flask import Flask, render_template, jsonify
import re

app = Flask(__name__)

def read_throughput():
    with open("monitorare.txt") as f:
        lines = f.readlines()

    throughputs = {"S1": [], "S2": [], "S3": [], "S4": []}
    current_switch = None

    for line in lines:
        match_switch = re.search(r"Throughput S(\d)", line)
        if match_switch:
            current_switch = "S" + match_switch.group(1)
            continue

        match_value = re.search(r" (\d+\.\d+)$", line.strip())
        if match_value and current_switch:
            val = float(match_value.group(1))
            if val > 0:
                throughputs[current_switch].append(val)

    return throughputs

@app.route('/')
def index():
    return render_template('web.html')

@app.route('/data')
def data():
    return jsonify(read_throughput())

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

