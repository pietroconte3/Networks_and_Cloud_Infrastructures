#!/usr/bin/python3
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, DEAD_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet
from ryu.lib import hub
import time

class SliceController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(SliceController, self).__init__(*args, **kwargs)
        self.datapaths = {}
        self.flow_stats = {}
        hub.spawn(self._monitor)

    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                match=match, instructions=inst,
                                idle_timeout=0, hard_timeout=0)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        dpid = datapath.id

        match = parser.OFPMatch()
        self.add_flow(datapath, 0, match, [])

        H1 = "00:00:00:00:00:01"
        H2 = "00:00:00:00:00:02"
        H3 = "00:00:00:00:00:03"
        H4 = "00:00:00:00:00:04"

        if dpid == 1:
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=1), [parser.OFPActionOutput(3)])
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=3), [parser.OFPActionOutput(1)])
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=2), [parser.OFPActionOutput(4)])
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=4), [parser.OFPActionOutput(2)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=1, eth_src=H1, eth_dst=H3), [parser.OFPActionOutput(3)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=3, eth_src=H3, eth_dst=H1), [parser.OFPActionOutput(1)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=2, eth_src=H2, eth_dst=H4), [parser.OFPActionOutput(4)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=4, eth_src=H4, eth_dst=H2), [parser.OFPActionOutput(2)])

        elif dpid == 2:
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=1), [parser.OFPActionOutput(2)])
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=2), [parser.OFPActionOutput(1)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=1, eth_src=H1, eth_dst=H3), [parser.OFPActionOutput(2)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=2, eth_src=H3, eth_dst=H1), [parser.OFPActionOutput(1)])

        elif dpid == 3:
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=1), [parser.OFPActionOutput(2)])
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=2), [parser.OFPActionOutput(1)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=1, eth_src=H2, eth_dst=H4), [parser.OFPActionOutput(2)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=2, eth_src=H4, eth_dst=H2), [parser.OFPActionOutput(1)])

        elif dpid == 4:
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=3), [parser.OFPActionOutput(1)])
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=1), [parser.OFPActionOutput(3)])
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=4), [parser.OFPActionOutput(2)])
            self.add_flow(datapath, 50, parser.OFPMatch(eth_type=0x0806, in_port=2), [parser.OFPActionOutput(4)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=3, eth_src=H1, eth_dst=H3), [parser.OFPActionOutput(1)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=1, eth_src=H3, eth_dst=H1), [parser.OFPActionOutput(3)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=4, eth_src=H2, eth_dst=H4), [parser.OFPActionOutput(2)])
            self.add_flow(datapath, 30, parser.OFPMatch(eth_type=0x0800, in_port=2, eth_src=H4, eth_dst=H2), [parser.OFPActionOutput(4)])

    @set_ev_cls(ofp_event.EventOFPStateChange, [MAIN_DISPATCHER, DEAD_DISPATCHER])
    def _state_change_handler(self, ev):
        datapath = ev.datapath
        if ev.state == MAIN_DISPATCHER:
            if datapath.id not in self.datapaths:
                self.logger.info('register datapath: %016x', datapath.id)
                self.datapaths[datapath.id] = datapath
        elif ev.state == DEAD_DISPATCHER:
            if datapath.id in self.datapaths:
                self.logger.info('unregister datapath: %016x', datapath.id)
                del self.datapaths[datapath.id]

    def _monitor(self):
        while True:
            for dp in self.datapaths.values():
                self._request_stats(dp)
            hub.sleep(10)

    def _request_stats(self, datapath):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        req = parser.OFPFlowStatsRequest(datapath)
        datapath.send_msg(req)
        req = parser.OFPPortStatsRequest(datapath, 0, ofproto.OFPP_ANY)
        datapath.send_msg(req)

    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def _flow_stats_reply_handler(self, ev):
        body = ev.msg.body
        dpid = ev.msg.datapath.id
        current_time = time.time()
        self.logger.info('--- Throughput S%d (Mbps) ---', dpid)
        self.logger.info('match                            Throughput (Mbps)')

        # Scrive intestazione per ogni switch nel file
        with open("monitorare.txt", "a") as f:
            f.write(f"\nThroughput S{dpid}\n")

        for stat in sorted([flow for flow in body if flow.priority != 0],
                           key=lambda flow: flow.priority, reverse=True):
            match_str = str(stat.match)
            flow_key = (dpid, match_str)
            current_bytes = stat.byte_count
            if flow_key in self.flow_stats:
                prev_time, prev_bytes = self.flow_stats[flow_key]
                delta_time = current_time - prev_time
                if delta_time > 0 and current_bytes >= prev_bytes:
                    delta_bytes = current_bytes - prev_bytes
                    throughput_mbps = (delta_bytes * 8) / (delta_time * 1000000)
                    match_display = match_str.replace('OFPMatch(', '').replace(')', '').ljust(30)
                    self.logger.info('%s %0.3f', match_display, throughput_mbps)

                    # ✅ Scrive il throughput nel file per la dashboard
                    with open("monitorare.txt", "a") as f:
                        f.write(f"{match_display} {throughput_mbps:.3f}\n")

            self.flow_stats[flow_key] = (current_time, current_bytes)

        self.logger.info('--------------------------------- --------------------\n')

